## Music App with recommendation system

This app not just allows you to listen to your favourite songs, but also recommends you new songs based on your history.

Basic app layout: https://github.com/buckyroberts/viberr
